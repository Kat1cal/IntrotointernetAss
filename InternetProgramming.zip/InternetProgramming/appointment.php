<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_name'])) {
    header('Location: login.html'); // Redirect to login page if not logged in
    exit();
}

$user_name = $_SESSION['user_name'];

// Include database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clinic_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get booked slots for the current date
$currentDate = date('Y-m-d');
$sql = "SELECT appointment_time FROM appointments WHERE appointment_date = '$currentDate'";
$result = $conn->query($sql);

$bookedSlots = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $bookedSlots[] = $row['appointment_time'];
    }
}

// Convert PHP array to JavaScript array
$bookedSlotsJson = json_encode($bookedSlots);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appointment</title>
    <link rel="stylesheet" href="css/bookstyle.css">
    <link rel="stylesheet" href="css/navigator.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css'>
    <link rel="icon" type="image/x-icon" href="images/Logo.png">
    <style>
        .time-slots-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            margin-top: 20px;
        }
        .time-slot {
            background-color: #f0f0f0;
            border: 1px solid #ddd;
            padding: 10px 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .time-slot:hover {
            background-color: #e0e0e0;
        }
        .time-slot.selected {
            background-color: #28a745;
            color: white;
        }
        .time-slot.disabled {
            background-color: #6c757d;
            color: #e9ecef;
            cursor: not-allowed;
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <section class="header">
        <!-- Website Logo -->
        <div class="logo">
            <img src="img/Logo.png" alt="Zenith Clinic Logo">
            <h3>Zenith Health Clinic</h3>
        </div>

        <!-- Navigation Bar -->
        <div class="navigation">
            <input type="checkbox" class="navigation__checkbox" id="toggle">
            <label for="toggle" class="navigation__button">
                <span class="navigation__icon">&nbsp;</span>
            </label>

            <button class="btn sign-in-button"><?php echo htmlspecialchars($user_name); ?></button>

            <nav class="navigation__nav">
                <ul class="navigation__list">
                    <li><a href="home.php" class="navigation__link">Home</a></li>
                    <li><a href="appointment.php" class="navigation__link">Appointment</a></li>
                    <li><a href="logout.php" class="navigation__link">Logout</a></li>
                </ul>
            </nav>
        </div>
    </section>

    <!-- Appointment Form -->
    <section class="appointment-form">
        <div class="container">
            <h2>Book an Appointment</h2>
            <form id="appointmentForm" action="submit_appointment.php" method="POST">
                <div class="form-input-box">
                    <label for="date">Appointment Date:</label>
                    <input type="date" id="date" name="date" 
                           placeholder="Select a date" 
                           min="<?php echo date('Y-m-d'); ?>" 
                           max="<?php echo date('Y-m-d', strtotime('+1 month')); ?>" 
                           required>
                </div>

                <div class="form-input-box">
                    <label>Select Time Slot:</label>
                    <div class="time-slots-container" id="timeSlotsContainer">
                        <!-- Time slots will be dynamically populated -->
                    </div>
                    <input type="hidden" id="selectedTimeSlot" name="time" required>
                </div>

                <div class="form-input-box">
                    <label for="message">Additional Message (Optional):</label>
                    <textarea id="message" name="message" rows="4" placeholder="Enter any additional information"></textarea>
                </div>

                <div class="button form-input-box">
                    <input type="submit" value="Next" id="submitButton" disabled>
                </div>
            </form>
        </div>
    </section>

    
    <script src = "javascript/appoint.js"></script>
</body>
</html>
