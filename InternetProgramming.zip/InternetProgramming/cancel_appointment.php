<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clinic_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    error_log('Connection failed: ' . $conn->connect_error);
    echo json_encode(['success' => false, 'message' => 'Connection failed']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['appointment_id'])) {
    $appointment_id = $_POST['appointment_id'];

    // Log the appointment ID for debugging
    error_log('Received appointment ID: ' . $appointment_id);

    // Begin transaction
    $conn->begin_transaction();

    try {
        // Retrieve appointment details before deletion
        $select_sql = "SELECT * FROM confirmed_bookings WHERE id = ?";
        $select_stmt = $conn->prepare($select_sql);
        if ($select_stmt === false) {
            error_log('Prepare failed: ' . $conn->error);
            echo json_encode(['success' => false, 'message' => 'Prepare failed']);
            exit();
        }
        $select_stmt->bind_param("i", $appointment_id);
        $select_stmt->execute();
        $result = $select_stmt->get_result();

        if ($result->num_rows === 0) {
            throw new Exception('Appointment not found');
        }

        $appointment = $result->fetch_assoc();

        // Log the appointment details for debugging
        error_log('Appointment details: ' . print_r($appointment, true));

        // Send cancellation email
        $mail = new PHPMailer(true);

        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'minkailee7637@gmail.com';
            $mail->Password = 'zfcn hhsg xexi qpwl';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Recipients
            $mail->setFrom('noreply@zenithclinic.com', 'Zenith Health Clinic');
            $mail->addAddress($appointment['email']);

            // Email content
            $mail->isHTML(true);
            $mail->Subject = 'Appointment Cancellation Notification';
            $mail->Body = '
                <h3>Appointment Cancellation</h3>
                <p>Dear ' . htmlspecialchars($appointment['user_name']) . ',</p>
                <p>We regret to inform you that your appointment has been cancelled:</p>
                <ul>
                    <li><strong>Date:</strong> ' . date('Y-m-d', strtotime($appointment['appointment_date'])) . '</li>
                    <li><strong>Time:</strong> ' . date('H:i:s', strtotime($appointment['appointment_time'])) . '</li>
                </ul>
                <p>If you have any questions, please contact our clinic directly.</p>
                <p>We apologize for any inconvenience.</p>
            ';

            // Send the email
            $mail->send();

        } catch (Exception $mailException) {
            error_log('Failed to send cancellation email: ' . $mailException->getMessage());
            throw new Exception('Failed to send cancellation email');
        }

        // Delete from confirmed_bookings
        $delete_sql_confirmed = "DELETE FROM confirmed_bookings WHERE id = ?";
        $delete_stmt_confirmed = $conn->prepare($delete_sql_confirmed);
        if ($delete_stmt_confirmed === false) {
            error_log('Failed to prepare delete statement for confirmed_bookings: ' . $conn->error);
            throw new Exception('Failed to prepare delete statement for confirmed_bookings');
        }
        $delete_stmt_confirmed->bind_param("i", $appointment_id);
        $delete_stmt_confirmed->execute();
        if ($delete_stmt_confirmed->affected_rows === 0) {
            error_log('Failed to delete appointment from confirmed_bookings: No rows affected');
            throw new Exception('Failed to delete appointment from confirmed_bookings');
        }

        // Delete from doctor_bookings based on common fields
        $delete_sql_doctor = "DELETE FROM doctor_bookings WHERE user_name = ? AND appointment_date = ? AND appointment_time = ?";
        $delete_stmt_doctor = $conn->prepare($delete_sql_doctor);
        if ($delete_stmt_doctor === false) {
            error_log('Failed to prepare delete statement for doctor_bookings: ' . $conn->error);
            throw new Exception('Failed to prepare delete statement for doctor_bookings');
        }
        $delete_stmt_doctor->bind_param("sss", $appointment['user_name'], $appointment['appointment_date'], $appointment['appointment_time']);
        $delete_stmt_doctor->execute();
        if ($delete_stmt_doctor->affected_rows === 0) {
            error_log('Failed to delete appointment from doctor_bookings: No rows affected');
            throw new Exception('Failed to delete appointment from doctor_bookings');
        }

        // Delete from appointments
        $delete_sql_appointments = "DELETE FROM appointments WHERE user_name = ? AND appointment_date = ? AND appointment_time = ?";
        $delete_stmt_appointments = $conn->prepare($delete_sql_appointments);
        if ($delete_stmt_appointments === false) {
            error_log('Failed to prepare delete statement for appointments: ' . $conn->error);
            throw new Exception('Failed to prepare delete statement for appointments');
        }
        $delete_stmt_appointments->bind_param("sss", $appointment['user_name'], $appointment['appointment_date'], $appointment['appointment_time']);
        $delete_stmt_appointments->execute();
        if ($delete_stmt_appointments->affected_rows === 0) {
            error_log('Failed to delete appointment from appointments: No rows affected');
            throw new Exception('Failed to delete appointment from appointments');
        }

        // Commit transaction
        $conn->commit();

        echo json_encode([
            'success' => true,
            'message' => 'Appointment cancelled and cancellation email sent.',
            'email_sent' => true
        ]);

    } catch (Exception $e) {
        // Rollback transaction
        $conn->rollback();
        error_log('Error during transaction: ' . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage(),
            'email_sent' => false
        ]);
    } finally {
        // Close statements
        if (isset($select_stmt)) $select_stmt->close();
        if (isset($delete_stmt_confirmed)) $delete_stmt_confirmed->close();
        if (isset($delete_stmt_doctor)) $delete_stmt_doctor->close();
        if (isset($delete_stmt_appointments)) $delete_stmt_appointments->close();
    }
}

$conn->close();
?>
