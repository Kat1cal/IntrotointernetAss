<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_name'])) {
    header('Location: login.html'); // Redirect to login page if not logged in
    exit();
}

$user_name = $_SESSION['user_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Doctors</title>
    <link rel="stylesheet" href="css/doctorstyle.css">
    <link rel="stylesheet" href="css/navigator.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="images/Logo.png">
</head>
<body>
    <section class="header">
        <!-- Website Logo -->
        <div class="logo">
            <img src="img/Logo.png" alt="Zenith Clinic Logo">
            <h3>Zenith Health Clinic</h3>
        </div>
        
        <!-- Navigation Bar -->
        <div class="navigation">
            <input type="checkbox" class="navigation__checkbox" id="toggle">
            <label for="toggle" class="navigation__button">
                <span class="navigation__icon">&nbsp;</span>
            </label>

            <button class="btn sign-in-button"><?php echo htmlspecialchars($user_name); ?></button>

            <nav class="navigation__nav">
                <ul class="navigation__list">
                    <li><a href="home.php" class="navigation__link">Home</a></li>
                    <li><a href="appointment.php" class="navigation__link">Appointment</a></li>
                    <li><a href="logout.php" class="navigation__link">Logout</a></li>
                </ul>
            </nav>
        </div>
    </section>

    <!-- Doctors selection -->
    <section class="doctor-selection">
        <div class="container">
            <h2 class="section-title">Select a Doctor</h2>
            
            <!-- Email Input -->
            <div class="email-input-container">
                <label for="email-input">Re-enter your email:</label>
                <input type="email" id="email-input" placeholder="e.g., example@gmail.com" required>
            </div>
            
            <div class="doctor-grid">
                <!-- Doctor 1 -->
                <div class="doctor-card">
                    <img src="img/doctor-1.png" alt="Doctor 1">
                    <h3>Dr. Shankar</h3>
                    <p>Cardiologist</p>
                    <button class="btn book-now" data-doctor="Dr. Shankar" data-specialty="Cardiologist">Book Now</button>
                </div>
                <!-- Doctor 2 -->
                <div class="doctor-card">
                    <img src="img/Doctor-2.png" alt="Doctor 2">
                    <h3>Dr. Jane</h3>
                    <p>Neurologist</p>
                    <button class="btn book-now" data-doctor="Dr. Jane" data-specialty="Neurologist">Book Now</button>
                </div>
                <!-- Doctor 3 -->
                <div class="doctor-card">
                    <img src="img/doctor-3.png" alt="Doctor 3">
                    <h3>Dr. Chow Kok Soon</h3>
                    <p>Orthopedic Surgeon</p>
                    <button class="btn book-now" data-doctor="Dr. Chow Kok Soon" data-specialty="Orthopedic Surgeon">Book Now</button>
                </div>
            </div>
    <script src= "javascript/selectdoc.js"></script>
</body>
</html>
