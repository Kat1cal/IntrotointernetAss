<?php
// Start session
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clinic_db";

// Ensure JSON response format
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_name'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

$user_name = $_SESSION['user_name']; // Logged-in patient's username

// Get the POST data
$data = json_decode(file_get_contents('php://input'), true);
if (!$data || !isset($data['doctor']) || !isset($data['specialty']) || !isset($data['email']) || !isset($data['date']) || !isset($data['time'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid data received']);
    exit();
}

$doctor = $data['doctor'];
$specialty = $data['specialty'];
$email = $data['email'];
$date = $data['date'];
$time = $data['time'];

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Insert the booking into the database
$sql = "INSERT INTO doctor_bookings (user_name, doctor, specialty, email, appointment_date, appointment_time, status) VALUES (?, ?, ?, ?, ?, ?, 'Pending')";
$stmt = $conn->prepare($sql);

if ($stmt) {
    $stmt->bind_param("ssssss", $user_name, $doctor, $specialty, $email, $date, $time);

    if ($stmt->execute()) {
        // Return success JSON response
        echo json_encode(['success' => true, 'message' => 'Booking successful']);
    } else {
        // Query execution failed
        echo json_encode(['success' => false, 'message' => 'Failed to save booking: ' . $stmt->error]);
    }

    $stmt->close();
} else {
    // Query preparation failed
    echo json_encode(['success' => false, 'message' => 'Error preparing query: ' . $conn->error]);
}

$conn->close();
?>
