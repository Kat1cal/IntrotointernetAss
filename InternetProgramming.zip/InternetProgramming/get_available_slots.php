<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clinic_db";

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_name'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Process the POST request for available slots
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect POST data
    $date = $_POST['date'];

    // Query to get booked time slots for the selected date
    $sql = "SELECT appointment_time FROM appointments WHERE appointment_date = '$date'";
    $result = $conn->query($sql);

    $bookedSlots = [];
    if ($result->num_rows > 0) {
        // Fetch booked time slots
        while($row = $result->fetch_assoc()) {
            $bookedSlots[] = $row['appointment_time'];
        }
    }

    // Define all possible time slots
    $allTimeSlots = [
        '09:00', '10:00', '11:00', '12:00',
        '13:00', '14:00', '15:00', '16:00',
        '17:00', '18:00'
    ];

    // Determine available time slots
    $availableSlots = array_diff($allTimeSlots, $bookedSlots);

    // Return available slots as JSON
    echo json_encode($availableSlots);
    
    $conn->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
