<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clinic_db";

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_name'])) {
    echo json_encode(['success' => false, 'message' => 'User  not logged in']);
    exit();
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Process the POST request for booked slots
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect POST data
    $date = $_POST['date'];

    // Query to get booked appointments for the selected date
    $sql = "SELECT appointment_time FROM appointments WHERE appointment_date = '$date'";
    $result = $conn->query($sql);

    // Array to hold booked time slots
    $bookedSlots = [];
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $bookedSlots[] = $row['appointment_time'];
        }
    }

    // Return booked slots
    echo json_encode($bookedSlots);

    $conn->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>