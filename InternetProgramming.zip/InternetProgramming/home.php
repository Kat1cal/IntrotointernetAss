<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_name'])) {
    header('Location: login.html'); // Redirect to login page if not logged in
    exit();
}

$user_name = $_SESSION['user_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zenith Health Clinic</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/navigator.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="images/Logo.png">
</head>
<body>
    <section class="header">
        <!-- Website Logo -->
        <div class="logo">
            <img src="img/Logo.png" alt="Zenith Clinic Logo">
            <h3>Zenith Health Clinic</h3>
        </div>
        
        <!-- Navigation Bar -->
        <div class="navigation">
            <input type="checkbox" class="navigation__checkbox" id="toggle">
            <label for="toggle" class="navigation__button">
                <span class="navigation__icon">&nbsp;</span>
            </label>

            <button class="btn sign-in-button"><?php echo htmlspecialchars($user_name); ?></button>

            <div class="navigation__nav">
                <ul class="navigation__list">
                    <li><a href="home.php" class="navigation__link">Home</a></li>
                    <li><a href="appointment.php" class="navigation__link">Appointment</a></li>
                    <li><a href="logout.php" class="navigation__link">Logout</a></li> <!-- Logout link -->
                </ul>
            </div>
        </div>
    </section>
    
    <div class="background-image"><img src="img/clinicbackground.png"></div>

    <section class="welcome">
        <div class="content">
            <h1>Welcome to Zenith Health</h1>
            <p>Your health is our priority. Book your appointment today!</p>
            <a href="appointment.php" class="btn">Book Now</a>
        </div>
    </section>

    <!--Footer Section-->
    <section class="footer">
        <div class="icons">
        </div>
        <h6 style="color: rgb(255, 255, 255);">© <span id = "currentYear"></span> 2024 Coded With Visual Studio Code - Website owned by Zenith Health Clinic </h6></a>
        <h6 style="color: rgb(255, 255, 255);">Coded By Lee Kai Min Team Copyright Reserved</h6>
    </section>
    <script src="script.js"></script>
</body>
</html>
