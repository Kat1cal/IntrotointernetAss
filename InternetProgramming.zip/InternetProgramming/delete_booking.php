<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clinic_db";

// Hide PHP errors
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    error_log('Connection failed: ' . $conn->connect_error);
    echo json_encode(['success' => false, 'message' => 'Connection failed']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $booking_id = $_POST['booking_id'];

    // Begin transaction
    $conn->begin_transaction();

    try {
        // Retrieve booking details before deletion
        $select_sql = "SELECT * FROM doctor_bookings WHERE id = ?";
        $select_stmt = $conn->prepare($select_sql);
        if ($select_stmt === false) {
            error_log('Prepare failed: ' . $conn->error);
            echo json_encode(['success' => false, 'message' => 'Prepare failed']);
            exit();
        }
        $select_stmt->bind_param("i", $booking_id);
        $select_stmt->execute();
        $result = $select_stmt->get_result();

        if ($result->num_rows === 0) {
            throw new Exception('Booking not found');
        }

        $booking = $result->fetch_assoc();

        // Log the appointment details for debugging
        error_log('Booking details: ' . print_r($booking, true));

        // Delete from doctor_bookings
        $delete_sql_doctor = "DELETE FROM doctor_bookings WHERE user_name = ? AND appointment_date = ? AND appointment_time = ?";
        $delete_stmt_doctor = $conn->prepare($delete_sql_doctor);
        if ($delete_stmt_doctor === false) {
            error_log('Failed to prepare delete statement for doctor_bookings: ' . $conn->error);
            throw new Exception('Failed to prepare delete statement for doctor_bookings');
        }
        $delete_stmt_doctor->bind_param("sss", $booking['user_name'], $booking['appointment_date'], $booking['appointment_time']);
        $delete_stmt_doctor->execute();
        if ($delete_stmt_doctor->affected_rows === 0) {
            error_log('Failed to delete booking from doctor_bookings: No rows affected');
            throw new Exception('Failed to delete booking from doctor_bookings');
        }

        // Delete from appointments
        $delete_appointment_sql = "DELETE FROM appointments WHERE user_name = ? AND appointment_date = ? AND appointment_time = ?";
        $delete_appointment_stmt = $conn->prepare($delete_appointment_sql);
        if ($delete_appointment_stmt === false) {
            error_log('Failed to prepare appointment delete statement: ' . $conn->error);
            throw new Exception('Failed to prepare appointment delete statement');
        }
        $delete_appointment_stmt->bind_param("sss", $booking['user_name'], $booking['appointment_date'], $booking['appointment_time']);
        $delete_appointment_stmt->execute();
        if ($delete_appointment_stmt->affected_rows === 0) {
            error_log('Failed to delete appointment from appointments: No rows affected');
            throw new Exception('Failed to delete appointment from appointments');
        }

        if ($booking['status'] === 'pending') {
            // Send cancellation email
            $mail = new PHPMailer(true);

            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'minkailee7637@gmail.com';
                $mail->Password = 'zfcn hhsg xexi qpwl';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Recipients
                $mail->setFrom('noreply@zenithclinic.com', 'Zenith Health Clinic');
                $mail->addAddress($booking['email']);

                // Email content
                $mail->isHTML(true);
                $mail->Subject = 'Appointment Cancellation Notification';
                $mail->Body = '
                    <h3>Appointment Cancellation</h3>
                    <p>Dear ' . htmlspecialchars($booking['user_name']) . ',</p>
                    <p>We regret to inform you that your appointment has been cancelled:</p>
                    <ul>
                        <li><strong>Date:</strong> ' . date('Y-m-d', strtotime($booking['appointment_date'])) . '</li>
                        <li><strong>Time:</strong> ' . date('H:i:s', strtotime($booking['appointment_time'])) . '</li>
                        <li><strong>Doctor:</strong> ' . htmlspecialchars($booking['doctor']) . '</li>
                    </ul>
                    <p>If you have any questions, please contact our clinic directly.</p>
                    <p>We apologize for any inconvenience.</p>
                ';

                // Send the email
                $mail->send();

                echo json_encode([
                    'success' => true,
                    'message' => 'Booking and appointments deleted, cancellation email sent',
                    'email_sent' => true
                ]);

            } catch (Exception $mailException) {
                // Rollback transaction
                $conn->rollback();
                error_log('Failed to send cancellation email: ' . $mailException->getMessage());
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to send cancellation email',
                    'email_sent' => false
                ]);
                exit();
            }
        } else {
            echo json_encode([
                'success' => true,
                'message' => 'Booking and appointments deleted',
                'email_sent' => false
            ]);
        }

        // Commit transaction
        $conn->commit();

    } catch (Exception $e) {
        // Rollback transaction
        $conn->rollback();
        error_log('Error during transaction: ' . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    } finally {
        // Close statements
        if (isset($select_stmt)) $select_stmt->close();
        if (isset($delete_stmt_doctor)) $delete_stmt_doctor->close();
        if (isset($delete_appointment_stmt)) $delete_appointment_stmt->close();
    }
}

// Close connection
$conn->close();
?>
