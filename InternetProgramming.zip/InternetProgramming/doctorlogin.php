<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $email = $_GET['email'];
    $password = $_GET['password'];

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password_db = "";
    $dbname = "clinic_db";

    $conn = new mysqli($servername, $username, $password_db, $dbname);

    if ($conn->connect_error) {
        die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
    }

    // Check for doctor credentials
    $sql = "SELECT * FROM users WHERE email = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['user_name'] = $user['name']; // Set session variable

        // Check if it's a doctor
        if ($user['role'] === 'doctor') { // Assuming 'role' column distinguishes user roles
            header('Location: doctor_home.php'); // Redirect to doctor home page
        } else {
            echo json_encode(['success' => false, 'message' => 'Access denied. Not a doctor.']);
        }
        exit();
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
    }

    $stmt->close();
    $conn->close();
}
?>
