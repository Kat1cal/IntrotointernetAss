<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_name'])) {
    header('Location: login.html'); // Redirect to login page if not logged in
    exit();
}

$user_name = $_SESSION['user_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/adminstyle.css">
    <link rel="stylesheet" href="css/navigator.css">
    <link rel="icon" type="image/x-icon" href="images/Logo.png">
</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="logo">
            <img src="img/Logo.png" alt="Zenith Clinic Logo">
            <h3>Zenith Health Clinic</h3>
        </div>
        
        <button class="btn sign-in-button"><?php echo htmlspecialchars($user_name); ?></button>

        <!-- Navigation Bar -->
        <div class="navigation">
            <input type="checkbox" class="navigation__checkbox" id="toggle">
            <label for="toggle" class="navigation__button">
                <span class="navigation__icon">&nbsp;</span>
            </label>
            <nav class="navigation__nav">
                <ul class="navigation__list">
                    <li><a href="logout.php" class="navigation__link">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Admin Dashboard Section -->
<main class="admin-dashboard">
    <div class="container">
        <table class="bookings-table">
            <thead>
                <tr>
                    <th colspan="8" class="table-title">Patient Bookings</th>
                </tr>
                <tr>
                    <th>Patient Name</th>
                    <th>Doctor</th>
                    <th>Specialty</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="bookings-table-body">
                <!-- Dynamic content loaded here -->
            </tbody>
        </table>
    </div>
    </main>
    <script src= "javascript/admin.js"></script>
</body>
</html>
