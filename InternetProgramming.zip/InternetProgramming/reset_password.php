<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clinic_db";

try {
    // Establish database connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $newPassword = trim($_POST['new_password']);

    try {
        // Check if the email exists in the database
        $query = "SELECT * FROM users WHERE email = :email";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            // Update the password for the user
            $updateQuery = "UPDATE users SET password = :password WHERE email = :email";
            $updateStmt = $pdo->prepare($updateQuery);
            $updateStmt->bindParam(':password', $newPassword); // Storing plain text password
            $updateStmt->bindParam(':email', $email);

            if ($updateStmt->execute()) {
                echo "<script>alert('Password reseted successfully!'); window.location.href = 'login.html';</script>";
            } else {
                echo "<script>alert('Failed to update the password. Please try again.'); history.back();</script>";
            }
        } else {
            echo "<script>alert('The email is not recognized. Please try again!'); history.back();</script>";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
