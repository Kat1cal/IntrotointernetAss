    <?php
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "clinic_db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
    }

    // Process the form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Collect POST data
        $name = $_POST['name'];
        $email = $_POST['email'];
        $identityCard = $_POST['identity_card'];
        $contactNumber = $_POST['contact_number'];
        $password = $_POST['password'];

        // Insert the data into the database
        $sql = "INSERT INTO users (name, email, identityCard, contactNumber, password) VALUES ('$name', '$email', '$identityCard', '$contactNumber', '$password')";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
        }

        $conn->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    }
    ?>
