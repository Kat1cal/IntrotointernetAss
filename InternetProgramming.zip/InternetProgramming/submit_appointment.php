<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clinic_db";

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_name'])) {
    echo "<script>alert('User not logged in'); window.location.href = 'login.html';</script>";
    exit();
}

$user_name = $_SESSION['user_name'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo "<script>alert('Connection failed: " . $conn->connect_error . "'); window.location.href = 'appointment.php';</script>";
    exit();
}

// Process the POST request for appointment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect POST data
    $date = $_POST['date'];
    $time = $_POST['time'];
    $message = $_POST['message'];

    // Insert the data into the appointments table
    $sql = "INSERT INTO appointments (user_name, appointment_date, appointment_time, message) VALUES ('$user_name', '$date', '$time', '$message')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
                alert('Select a Doctor to confirm appointment.');
                window.location.href = 'selectdoctors.php?date={$date}&time={$time}';
              </script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href = 'appointment.php';</script>";
    }

    $conn->close();
} else {
    echo "<script>alert('Invalid request method'); window.location.href = 'appointment.php';</script>";
}
?>
