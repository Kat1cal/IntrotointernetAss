document.querySelectorAll('.book-now').forEach(button => {
    button.addEventListener('click', function () {
        const doctor = this.getAttribute('data-doctor');
        const specialty = this.getAttribute('data-specialty');
        const email = document.getElementById('email-input').value;

        // Validate email input
        if (!email) {
            alert('Please enter your email.');
            return;
        }
        if (!/^\S+@\S+\.\S+$/.test(email)) {
            alert('Please enter a valid email address.');
            return;
        }

        const urlParams = new URLSearchParams(window.location.search);
        const date = urlParams.get('date');
        const time = urlParams.get('time');

        // Ensure date and time are present
        if (!date || !time) {
            alert('Missing appointment date or time.');
            return;
        }

        // Send booking data to the server
        fetch('book_doctor.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                doctor: doctor,
                specialty: specialty,
                email: email,
                date: date, // Include date
                time: time  // Include time
            }),
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Response Data:', data); // Log the response for debugging
            if (data.success) {
                alert(`You have successfully booked an appointment with ${doctor}. Booking details will be sent to you soon.`);
                // Redirect to home.php
                window.location.href = 'home.php';
            } else {
                alert(`Error: ${data.message}`);
            }
        })
        .catch(error => {
            console.error('Error:', error); // Log any errors
            alert('Something went wrong. Please try again.');
        });
    });
});
