function validateForm() {
    var email = document.getElementById('email').value;
    var newPassword = document.getElementById('new_password').value;
    var confirmPassword = document.getElementById('confirm_password').value;
    var emailError = document.getElementById('email_error');
    var passwordLengthError = document.getElementById('password_length_error');
    var passwordError = document.getElementById('password_error');

    var isValid = true;

    // Validate email format
    if (!validateEmail(email)) {
        emailError.style.display = 'block';
        isValid = false;
    } else {
        emailError.style.display = 'none';
    }

    // Validate password length
    if (newPassword.length < 6) {
        passwordLengthError.style.display = 'block';
        isValid = false;
    } else {
        passwordLengthError.style.display = 'none';
    }

    // Validate password match
    if (newPassword !== confirmPassword) {
        passwordError.style.display = 'block';
        isValid = false;
    } else {
        passwordError.style.display = 'none';
    }

    return isValid;
}

function validateEmail(email) {
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    return emailPattern.test(email);
}

function toggleLoginForm() {
    const loginContainer = document.getElementById('registration');

    if (loginContainer.style.opacity === '1') {
        loginContainer.style.transition = 'opacity 0.5s ease';
        loginContainer.style.opacity = '0';

        setTimeout(() => {
            loginContainer.style.display = 'none';
        }, 500);
    } else {
        loginContainer.style.display = 'flex';
        loginContainer.style.opacity = '0';
        loginContainer.style.transition = 'opacity 0.5s ease';

        setTimeout(() => {
            loginContainer.style.opacity = '1';
        }, 10);
    }
}