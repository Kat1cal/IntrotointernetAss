// Toggle Login Form Display
function toggleLoginForm() {
    const loginContainer = document.getElementById('registration');

    if (loginContainer.style.opacity === '1') {
        loginContainer.style.transition = 'opacity 0.5s ease';
        loginContainer.style.opacity = '0';

        setTimeout(() => {
            loginContainer.style.display = 'none';
        }, 500);
    } else {
        loginContainer.style.display = 'flex';
        loginContainer.style.opacity = '0';
        loginContainer.style.transition = 'opacity 0.5s ease';

        setTimeout(() => {
            loginContainer.style.opacity = '1';
        }, 10);
    }
}

// Validation Helpers
function validateEmail(email) {
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    return emailPattern.test(email);
}

function validateContactNumber(number) {
    const phonePattern = /^[0-9]{10,15}$/;
    return phonePattern.test(number);
}

function validateIdentityCard(identityCard) {
    const identityCardPattern = /^[0-9]{12}$/; // Requires exactly 12 digits
    return identityCardPattern.test(identityCard);
}

function showError(input, message) {
    const formBox = input.parentElement;
    const errorDisplay = formBox.querySelector('.error-message');

    if (!errorDisplay) {
        const errorElement = document.createElement('span');
        errorElement.className = 'error-message';
        errorElement.textContent = message;
        formBox.appendChild(errorElement);
        formBox.className = 'form-input-box error';
    }

    // Add event listener to clear error on input
    input.addEventListener('input', () => {
        clearError(input);
    });
}

function clearError(input) {
    const formBox = input.parentElement;
    const errorDisplay = formBox.querySelector('.error-message');

    if (errorDisplay) {
        errorDisplay.remove();
        formBox.classList.remove('error');
    }
}

function showSuccess(input) {
    const formBox = input.parentElement;
    const errorDisplay = formBox.querySelector('.error-message');

    if (errorDisplay) {
        errorDisplay.remove();
    }
    formBox.className = 'form-input-box success';
}

// Login Form Validation
document.querySelector('.login-form form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    const email = event.target[0].value;
    const password = event.target[1].value;

    let isValid = true;

    if (!validateEmail(email)) {
        showError(event.target[0], 'Invalid email format');
        isValid = false;
    } else {
        showSuccess(event.target[0]);
    }

    if (password.length < 6) {
        showError(event.target[1], 'Invalid password');
        isValid = false;
    } else {
        showSuccess(event.target[1]);
    }

    if (isValid) {
        fetch(`login.php?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Login Successful!');
                window.location.href = data.redirect; // Redirect to the appropriate page
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
});

// Signup Form Validation
document.querySelector('.signup-form form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    const name = event.target[0].value;
    const email = event.target[1].value;
    const identityCard = event.target[2].value;
    const contactNumber = event.target[3].value;
    const password = event.target[4].value;
    const confirmPassword = event.target[5].value;

    let isValid = true;

    if (name.length < 4) {
        showError(event.target[0], 'Minimum 4 characters required');
        isValid = false;
    } else {
        showSuccess(event.target[0]);
    }

    if (!validateEmail(email)) {
        showError(event.target[1], 'Invalid email format');
        isValid = false;
    } else {
        showSuccess(event.target[1]);
    }

    if (!validateIdentityCard(identityCard)) {
        showError(event.target[2], 'Identity card must be 12 digits');
        isValid = false;
    } else {
        showSuccess(event.target[2]);
    }

    if (!validateContactNumber(contactNumber)) {
        showError(event.target[3], 'Invalid contact number');
        isValid = false;
    } else {
        showSuccess(event.target[3]);
    }

    if (password.length < 6) {
        showError(event.target[4], 'Minimum 6 characters required');
        isValid = false;
    } else {
        showSuccess(event.target[4]);
    }

    if (password !== confirmPassword) {
        showError(event.target[5], 'Passwords do not match');
        isValid = false;
    } else {
        showSuccess(event.target[5]);
    }

    // If validation is successful, submit the form using fetch
    if (isValid) {
        const formData = new FormData(event.target);

        fetch('register.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show popup alert
                alert('Registration Successful!');
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
});

// Check Login Status
function checkLoginStatus(event, url) {
    const signInButton = document.querySelector('.sign-in-button');
    if (signInButton && signInButton.innerText === 'Sign in') {
        event.preventDefault();
        alert('Please log in first to book an appointment.');
    } else {
        window.location.href = url;
    }
}

// Toggle the password visibility using the lock icon
function togglePasswordVisibility() {
    var passwordField = document.getElementById("password");
    var lockIcon = document.getElementById("togglePassword");

    if (passwordField.type === "password") {
        passwordField.type = "text";
        lockIcon.classList.remove("fa-lock");
        lockIcon.classList.add("fa-unlock-alt");
    } else {
        passwordField.type = "password";
        lockIcon.classList.remove("fa-unlock-alt");
        lockIcon.classList.add("fa-lock");
    }
}
