document.addEventListener('DOMContentLoaded', function () {
    // Fetch bookings when the page loads
    fetch('fetch_bookings.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            const tableBody = document.getElementById('bookings-table-body');
            if (data.success) {
                console.log('Bookings:', data.bookings); // Debugging log
                // Populate the table with booking data
                data.bookings.forEach(item => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.user_name}</td>
                        <td>${item.doctor}</td>
                        <td>${item.specialty}</td>
                        <td>${new Date(item.appointment_date).toLocaleDateString()}</td>
                        <td>${item.appointment_time}</td>
                        <td id="status-${item.id}">${item.status || 'Pending'}</td>
                        <td>${item.email}</td>
                        <td class="action-buttons">
                            <button class="btn confirm-btn" data-id="${item.id}">Confirm</button>
                            <button class="btn delete-btn" data-id="${item.id}">Delete</button>
                        </td>`;
                    tableBody.appendChild(row);
                });

                // Add event listeners for Confirm and Delete buttons
                addButtonListeners();
            } else {
                console.error('Fetch error:', data.message); // Debugging log
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while fetching bookings. Please try again.');
        });
});

// Function to add event listeners to buttons
function addButtonListeners() {
    // Confirm button functionality
    document.querySelectorAll('.confirm-btn').forEach(button => {
        button.addEventListener('click', function () {
            const bookingId = this.getAttribute('data-id');
            fetch('confirm_booking.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `booking_id=${bookingId}`
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        // Update status to "Confirmed"
                        document.getElementById(`status-${bookingId}`).textContent = 'Confirmed';
                        alert(data.message);
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => console.error('Error:', error));
        });
    });

    // Delete button functionality
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function () {
            const bookingId = this.getAttribute('data-id');
            const confirmed = confirm("Are you sure you want to delete this booking?");
            if (confirmed) {
                fetch('delete_booking.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `booking_id=${bookingId}`
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            // Remove the booking row from the table
                            this.closest('tr').remove();
                            // Optional: Show different messages based on email sending
                            if (data.email_sent) {
                                alert('Booking deleted and cancellation email sent');
                            } else {
                                alert('Booking deleted');
                            }
                        } else {
                            alert(data.message);
                        }
                    })
                    .catch(error => console.error('Error:', error));
            }
        });
    });
}
