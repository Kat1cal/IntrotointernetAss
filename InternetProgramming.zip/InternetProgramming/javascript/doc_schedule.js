document.addEventListener('DOMContentLoaded', function () {
    // Fetch confirmed bookings when the page loads
    fetch('fetch_confirmed_bookings.php')
        .then(response => response.json())
        .then(data => {
            console.log('Fetched data:', data); // Debugging log
            const tableBody = document.getElementById('appointments-table-body');
            if (data.success) {
                console.log('Bookings:', data.bookings); // Debugging log
                // Populate the table with booking data
                data.bookings.forEach(item => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.user_name}</td>
                        <td>${new Date(item.appointment_date).toLocaleDateString()}</td>
                        <td>${item.appointment_time}</td>
                        <td id="status-${item.id}">${item.status || 'Pending'}</td>
                        <td>${item.email}</td>
                        <td class="action-buttons">
                            <button class="btn delete-btn" data-id="${item.id}">Cancel</button>
                        </td>`;
                    tableBody.appendChild(row);
                });

                // Add event listeners for Cancel buttons
                addButtonListeners();
            } else {
                console.error('No bookings found:', data.message); // Debugging log
                alert(data.message);
            }
        })
        .catch(error => console.error('Fetch error:', error));
});

// Function to add event listeners to buttons
function addButtonListeners() {
    // Cancel button functionality
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function () {
            const appointmentId = this.getAttribute('data-id');
            const row = this.closest('tr');
            const confirmed = confirm("Are you sure you want to cancel this appointment?");
            if (confirmed) {
                fetch('cancel_appointment.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `appointment_id=${appointmentId}`
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert(data.message);
                            // Remove the booking row from the table
                            row.remove();
                        } else {
                            alert(data.message);
                        }
                    })
                    .catch(error => console.error('Error:', error));
            }
        });
    });
}
