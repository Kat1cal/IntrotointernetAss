const dateInput = document.getElementById('date');
    const timeSlotsContainer = document.getElementById('timeSlotsContainer');
    const selectedTimeSlotInput = document.getElementById('selectedTimeSlot');
    const submitButton = document.getElementById('submitButton');

    // Predefined time slots
    const timeSlots = [
        '09:00', '10:00', '11:00', '12:00',
        '13:00', '14:00', '15:00', '16:00',
        '17:00', '18:00'
    ];

    // Function to populate time slots
    function populateTimeSlots(bookedSlots = []) {
        console.log('Booked slots:', bookedSlots); // Debugging statement
        // Remove seconds from booked slots
        const bookedSlotsWithoutSeconds = bookedSlots.map(slot => slot.slice(0, 5));
        console.log('Processed booked slots:', bookedSlotsWithoutSeconds); // Debugging statement

        timeSlotsContainer.innerHTML = '';
        timeSlots.forEach(slot => {
            const slotElement = document.createElement('div');
            slotElement.classList.add('time-slot');
            slotElement.textContent = slot;

            // Check if slot is booked
            if (bookedSlotsWithoutSeconds.includes(slot)) {
                slotElement.classList.add('disabled');
                slotElement.textContent += ' (Booked)';
                console.log(`Slot ${slot} is booked`); // Debugging statement
            } else {
                slotElement.addEventListener('click', () => selectTimeSlot(slotElement));
            }

            timeSlotsContainer.appendChild(slotElement);
        });
    }

    // Function to select a time slot
    function selectTimeSlot(slotElement) {
        if (slotElement.classList.contains('disabled')) return;

        // Remove selection from all slots
        document.querySelectorAll('.time-slot').forEach(slot => {
            slot.classList.remove('selected');
        });

        // Select the clicked slot
        slotElement.classList.add('selected');
        selectedTimeSlotInput.value = slotElement.textContent.replace(' (Booked)', '');
        submitButton.disabled = false;
        console.log(`Selected slot: ${slotElement.textContent}`); // Debugging statement
    }

    // Initial population of time slots
    populateTimeSlots();

    // Date change event listener
    dateInput.addEventListener('change', async () => {
        const selectedDate = dateInput.value;

        try {
            // Fetch booked slots for the selected date
            const response = await fetch('check_booked_slots.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ date: selectedDate })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const bookedSlots = await response.json();
            console.log('Fetched booked slots:', bookedSlots); // Debugging statement
            populateTimeSlots(bookedSlots);

            // Reset form
            selectedTimeSlotInput.value = '';
            submitButton.disabled = true;
        } catch (error) {
            console.error('Error fetching booked slots:', error);
            populateTimeSlots(); // Fallback to all slots
    }
});

