<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clinic_db";

// Hide PHP errors
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    error_log('Connection failed: ' . $conn->connect_error);
    echo json_encode(['success' => false, 'message' => 'Connection failed']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_id = $_POST['booking_id'];

    // Retrieve booking details
    $sql = "SELECT * FROM doctor_bookings WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log('Prepare failed: ' . $conn->error);
        echo json_encode(['success' => false, 'message' => 'Prepare failed']);
        exit();
    }
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $booking = $result->fetch_assoc();

        // Log booking details for debugging
        error_log("Booking details: " . print_r($booking, true));

        // Update booking status to "Confirmed"
        $update_sql = "UPDATE doctor_bookings SET status = 'Confirmed' WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        if ($update_stmt === false) {
            error_log('Failed to prepare statement: ' . $conn->error);
            echo json_encode(['success' => false, 'message' => 'Failed to prepare statement']);
            exit();
        }

        $update_stmt->bind_param("i", $booking_id);
        $update_stmt->execute();

        // Log affected rows and error for debugging
        error_log("Affected rows: " . $update_stmt->affected_rows);
        error_log("Update error: " . $update_stmt->error);

        if ($update_stmt->affected_rows > 0) {
            // Send confirmation email
            $mail = new PHPMailer(true);

            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'minkailee7637@gmail.com';
                $mail->Password = 'zfcn hhsg xexi qpwl';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Recipients
                $mail->setFrom('your_email@example.com', 'Zenith Health Clinic');
                $mail->addAddress($booking['email']);

                // Email content
                $mail->isHTML(true);
                $mail->Subject = 'Zenith Health Care Clinic Appointment Confirmed';
                $mail->Body = '
                    <h3>Your Appointment Has Been Confirmed</h3>
                    <p>Dear ' . $booking['user_name'] . ',</p>
                    <p>Your appointment has been confirmed with the following details:</p>
                    <ul>
                        <li><strong>Date:</strong> ' . date('Y-m-d', strtotime($booking['booking_date'])) . '</li>
                        <li><strong>Time:</strong> ' . date('H:i:s', strtotime($booking['booking_date'])) . '</li>
                        <li><strong>Doctor:</strong> ' . $booking['doctor'] . '</li>
                    </ul>
                    <p>Thank you for choosing our clinic!</p>
                ';

                // Send the email
                $mail->send();

                // Log successful operation
                error_log('Booking confirmed and email sent successfully');
                echo json_encode(['success' => true, 'message' => 'Booking confirmed and email sent successfully']);
            } catch (Exception $e) {
                // Log PHPMailer error
                error_log('Mailer Error: ' . $mail->ErrorInfo);
                echo json_encode(['success' => false, 'message' => 'Mailer Error: ' . $mail->ErrorInfo]);
            }
        } else {
            if ($update_stmt->error === '') {
                // Log that the status might already be 'Confirmed'
                error_log('Booking status might already be Confirmed');
                echo json_encode(['success' => true, 'message' => 'Booking was already confirmed and email has been sent']);
            } else {
                error_log('Failed to update booking status. Error: ' . $update_stmt->error);
                echo json_encode(['success' => false, 'message' => 'Failed to update booking status. Error: ' . $update_stmt->error]);
            }
        }
    } else {
        error_log('Booking not found');
        echo json_encode(['success' => false, 'message' => 'Booking not found']);
    }
}

// Insert into confirmed_bookings
$insert_sql = "INSERT INTO confirmed_bookings (user_name, appointment_date, appointment_time, status, email) VALUES (?, ?, ?, 'Confirmed', ?)";
$insert_stmt = $conn->prepare($insert_sql);
if ($insert_stmt === false) {
    error_log('Failed to prepare insert statement: ' . $conn->error);
    echo json_encode(['success' => false, 'message' => 'Failed to prepare insert statement']);
    exit();
}
$insert_stmt->bind_param("ssss", $booking['user_name'], $booking['appointment_date'], $booking['appointment_time'], $booking['email']);
$insert_stmt->execute();
$insert_stmt->close();
