<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clinic_db";

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_name'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]);
    exit();
}

// Process the POST request to check booked slots
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $date = $data['date'] ?? '';

    if (empty($date)) {
        echo json_encode(['success' => false, 'message' => 'Date not provided']);
        exit();
    }

    // Query to get booked time slots for the selected date
    $sql = "SELECT appointment_time FROM appointments WHERE appointment_date = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $date);
    $stmt->execute();
    $result = $stmt->get_result();

    $bookedSlots = [];
    if ($result->num_rows > 0) {
        // Fetch booked time slots
        while ($row = $result->fetch_assoc()) {
            $bookedSlots[] = $row['appointment_time'];
        }
    }

    // Return booked slots as JSON
    echo json_encode($bookedSlots);
    
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    echo json_encode($bookedSlots);

}
?>
